package engine.board;

public enum CellType {
    NORMAL, SAFE, ENTRY, BASE
}
