package ms3;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.effect.DropShadow;
import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.util.Duration;
import engine.Game;
import engine.board.Board;
import engine.board.Cell;
import exception.GameException;
import exception.InvalidCardException;
import exception.InvalidMarbleException;
import exception.SplitOutOfRangeException;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.control.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import model.Colour;
import model.card.Card;
import model.card.standard.Ace;
import model.card.standard.King;
import model.card.standard.Seven;
import model.card.standard.Standard;
import model.card.standard.Suit;
import model.card.wild.Burner;
import model.player.CPU;
import model.player.Marble;
import model.player.Player;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;

import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;



	public class view extends Application {
		
		
		// make window resizable
		//add shortcuts
		
		//attributes

	    private Stage primaryStage;
	    private Scene startScene;
	    Game game;
	    ImageView deck;
	    ImageView firepit;
	    GridPane gridpane;
	    int[][] trackCoords = new int[100][2];
	    int [][]safezone1 = {{24,13},{23,12},{22,12},{21,13} };
	    int [][]safezone2 = {{13,1},{13,2},{13,3},{13,4} };
	    int [][]safezone3 = {{1,12},{2,12},{3,12},{4,12} };
	    int [][]safezone4 = {{12,24},{12,23},{12,22},{12,21} };
	    
	    int [][] safezoneentrys = {{25,13},{13,0},{0,12},{12,25}};
	    int [] [] bases = {{25,11}, {11,0}, {0,14}, {14,25} };
	    ToggleGroup group;
	    String CPU1name= "Shawki";
	    String CPU2name= "Jana";
	    String CPU3name= "Hicham";
	    
	    
	  
	    
	    
	    
	    
	   
	    @Override
	    public void start(Stage primaryStage) {
	    	
	        this.primaryStage = primaryStage;
	        showStartScreen();
	    }

	    private void showStartScreen() {
	        StackPane root = new StackPane();
	        
	        
	        
	        // 1. Add Background Image
	        Image backgroundImage = new Image("/background.png"); // Make sure to add background.png to your resources
	        ImageView backgroundView = new ImageView(backgroundImage);
	        backgroundView.setFitWidth(1250);
	        backgroundView.setFitHeight(970);
	        backgroundView.setPreserveRatio(false);
	        
	        
	        // 2. Content Container
	        VBox content = new VBox(20);
	        content.setAlignment(Pos.CENTER);
	        content.setPadding(new Insets(40));
	        content.setStyle("-fx-background-color: rgba(0,0,0,0.7); -fx-background-radius: 20;");
	        content.setEffect(new DropShadow(20, Color.BLACK));
	        content.setStyle("-fx-background-color: transparent;"); // No overlay

	        

	        // 4. Input Section
	        VBox inputGroup = new VBox(15);
	        inputGroup.setAlignment(Pos.CENTER);
	        
	        Label nameLabel = new Label("ENTER YOUR NAME");
	        nameLabel.setStyle("-fx-text-fill: #ffffff; -fx-font-size: 18px;");

	        TextField nameInput = new TextField();
	        nameInput.setPromptText("Your Adventurer Name");
	        nameInput.setStyle("-fx-font-size: 16px; -fx-padding: 8 15; -fx-background-radius: 5;");
	        nameInput.setPrefWidth(300);

	        // 5. Start ToggleButton
	        ToggleButton startButton = new ToggleButton("BEGIN QUEST");
	        startButton.setStyle("-fx-font-size: 18px; -fx-font-weight: bold; " +
	                "-fx-background-color: #27ae60; -fx-text-fill: white; -fx-padding: 12 30; " +
	                "-fx-background-radius: 5;");
	        
	        // Hover Effects
	        startButton.setOnMouseEntered(e -> startButton.setStyle(
	            "-fx-background-color: #2ecc71; -fx-font-size: 18px; -fx-font-weight: bold; " +
	            "-fx-text-fill: white; -fx-padding: 12 30; -fx-background-radius: 5;"
	        ));
	        startButton.setOnMouseExited(e -> startButton.setStyle(
	            "-fx-background-color: #27ae60; -fx-font-size: 18px; -fx-font-weight: bold; " +
	            "-fx-text-fill: white; -fx-padding: 12 30; -fx-background-radius: 5;"
	        ));

	        // 6. Error Message
	        Label errorLabel = new Label();
	        errorLabel.setStyle("-fx-text-fill: #e74c3c; -fx-font-size: 14px;");

	        // 7. Assemble UI
	        inputGroup.getChildren().addAll(nameLabel, nameInput, startButton, errorLabel);
	        content.getChildren().addAll( inputGroup);
	        root.getChildren().addAll( backgroundView, content);

	        // 8. Button Action
	        startButton.setOnAction(e -> {
	            String playerName = nameInput.getText().trim();
	            if (!playerName.isEmpty()) {
	                try {
	                    game = new Game(playerName);
	                    startGame(playerName);
	                    
	                } catch (IOException ex) {
	                    errorLabel.setText("Error initializing game! Check console.");
	                    ex.printStackTrace();
	                }
	            } 
	            else {
	                errorLabel.setText("Please enter your name to continue!");
	                // Shake animation
	                TranslateTransition shake = new TranslateTransition(Duration.millis(70), nameInput);
	                shake.setFromX(0);
	                shake.setByX(10);
	                shake.setCycleCount(4);
	                shake.setAutoReverse(true);
	                shake.play();
	            }
	        });

	        // 9. Final Setup
	        startScene = new Scene(root, 1250, 970);
	        primaryStage.setTitle("Jackaroo Game");
	        primaryStage.setScene(startScene);
	        primaryStage.setResizable(true);
	        primaryStage.show();
	    }
	    
	    private Color helpercolor(Player player){
	    	if(player.getColour()==Colour.RED)
	    		return Color.RED;
	    	else if(player.getColour()==Colour.BLUE)
	    		return Color.BLUE;
	    	else if(player.getColour()==Colour.GREEN)
	    		return Color.GREEN;
	    	else
	    		return Color.YELLOW;
	    		    }
	    
	    private Color helpercolorofMarble(Marble marble){
	    	if(marble.getColour()==Colour.RED)
	    		return Color.RED;
	    	else if(marble.getColour()==Colour.BLUE)
	    		return Color.BLUE;
	    	else if(marble.getColour()==Colour.GREEN)
	    		return Color.GREEN;
	    	else
	    		return Color.YELLOW;
	    		    }

private void startGame(String humanName) {
	        
	    	primaryStage.setResizable(true);

	        BorderPane root = new BorderPane();
	        
	        
	        root.setStyle("-fx-background-color: black;");
	        
	        String name;
	        if(game.getCurrentPlayerIndex()==0)
	        	name=game.getPlayers().get(0).getName();
	        else if(game.getCurrentPlayerIndex()==1)
	        	name=CPU1name;
	        else if(game.getCurrentPlayerIndex()==2)
	        	name=CPU2name;
	        else
	        	name=CPU3name;
	        String name2 ;
	        
	        if(game.getCurrentPlayerIndex()==0)
	        	name2=CPU1name;
	        else if(game.getCurrentPlayerIndex()==1)
	        	name2=CPU2name;
	        else if(game.getCurrentPlayerIndex()==2)
	        	name2=CPU3name;
	        else
	        	name2=game.getPlayers().get(0).getName();

	        
	        // --- Top Info Bar + CPU2 ---
	        Label currentPlayer = new Label("Current Player: "+name);
	        Label nextPlayer = new Label("Next Player: "+ name2);
	        HBox infoBar = new HBox(20, currentPlayer, nextPlayer);
	        infoBar.setAlignment(Pos.CENTER);
	        infoBar.setStyle("-fx-padding: 10; -fx-background-color: lightgray;");

	        VBox cpu2Area = createPlayerAreaHorizontal(game.getPlayers().get(2));
	        VBox top = new VBox(10, infoBar, cpu2Area);
	        top.setAlignment(Pos.CENTER);
	        root.setTop(top);
	        

	        // --- Left and Right CPU Players (Vertical Cards) ---
	        root.setLeft(createPlayerAreaVertical("Shawki", game.getPlayers().get(1)));
	        root.setRight(createPlayerAreaVertical("Hicham", game.getPlayers().get(3)));

	        // --- Bottom: Player + Deck on Right ---
	        HBox bottomArea = new HBox();
	        VBox playerArea = createPlayerAreaHuman(humanName, game.getPlayers().get(0)); // add photos of cards
	        
	        deck = new ImageView("/Deck.jpg");
	        deck.setFitHeight(130);
	        deck.setFitWidth(100);
	        
	        Region spacer = new Region();
	        HBox.setHgrow(spacer, Priority.ALWAYS);

	        bottomArea.getChildren().addAll(playerArea, spacer, deck);
	        bottomArea.setAlignment(Pos.CENTER);
	        bottomArea.setStyle("-fx-padding: 10;");
	        root.setBottom(bottomArea);
	        
	        gridpane= new GridPane();
	        StackPane center = new StackPane(gridpane);
	        root.setCenter(center);
	        
	     // Set alignment to center the GridPane within its parent
	        gridpane.setAlignment(Pos.CENTER);
	        
	        gridpane.setHgap(1);
	        gridpane.setVgap(1);
	        
	        int index = 0;
		    int gridSize = 26;
		    
		 // 1. Bottom row from start (25,11) moving left to (25,0)
		    for (int col1 = 11; col1 >= 0 && index < 100; col1--) 
		        trackCoords[index++] = new int[]{25, col1};
		    

		    // 2. Left column from (24,0) up to (0,0)
		    for (int row1 = 24; row1 >= 0 && index < 100; row1--) 
		        trackCoords[index++] = new int[]{row1, 0};
		    

		    // 3. Top row from (0,1) to (0,25)
		    for (int col2 = 1; col2 < gridSize && index < 100; col2++) 
		        trackCoords[index++] = new int[]{0, col2};
		    

		    // 4. Right column from (1,25) down to (25,25)
		    for (int row = 1; row < gridSize && index < 100; row++) 
		        trackCoords[index++] = new int[]{row, 25};
		    

		    // 5. Bottom row from (25,24) moving left to (25,12)
		    for (int col = 24; col >= 12 && index < 100; col--) 
		        trackCoords[index++] = new int[]{25, col};
		    
		    
		   
	        
	        
	        for (int[] coord : trackCoords) {
	            place(gridpane, coord[0], coord[1], Color.WHITE);  
	        }

	        // Safe zones
	        for (int i = 24; i >= 21; i--)
	            place(gridpane, i, 13,Color.WHITE );    
	        for (int i=1 ;i<=4;i++)
	            place(gridpane, 13, i, Color.WHITE);      
	        for (int i =1 ;i<=4;i++)
	            place(gridpane, i, 12,Color.WHITE); 
	        for(int i=24 ;i>=21;i--)
	            place(gridpane, 12 , i, Color.WHITE); 
	        
	        
	        
	        //Highlight
	       
	        

	        // Loop over all children in the grid        // highlight b a lighter color
	        for (Node node : gridpane.getChildren()) {
	            Integer col = GridPane.getColumnIndex(node);
	            Integer row = GridPane.getRowIndex(node);

	            if (col == null || row == null) continue;

	            // Check against safezoneentrys
	            for (int[] coord : safezoneentrys) {
	                if (coord[0] == row && coord[1] == col) {
	                    Color strokeColor;
	                    if (row == 25)
	                        strokeColor = helpercolor(game.getPlayers().get(0));
	                    else if (row == 0)
	                        strokeColor = helpercolor(game.getPlayers().get(2));
	                    else if (col == 0)
	                        strokeColor = helpercolor(game.getPlayers().get(1));
	                    else
	                        strokeColor = helpercolor(game.getPlayers().get(3));
	                    
	                    StackPane stack = (StackPane)node;
	                    String hex = String.format("#%02X%02X%02X",
		    	        	    (int)(strokeColor.getRed() * 255),
		    	        	    (int)(strokeColor.getGreen() * 255),
		    	        	    (int)(strokeColor.getBlue() * 255)
		    	        	);

	                    stack.setStyle(
	            	    	    "-fx-background-color: white;" +
	            	    	    "-fx-background-radius: 50%;" + // rounded edges
	            	    	    "-fx-border-color:"+ hex+";" +
	            	    	    "-fx-border-radius: 50%;" +
	            	    	    "-fx-border-width: 3px;" +
	            	    	    "-fx-alignment: center;"
	            	    	);
	                }
	            }

	            for (int[] coord : bases) {
	                if (coord[0] == row && coord[1] == col) {
	                    Color strokeColor;
	                    if (row == 25)
	                        strokeColor = helpercolor(game.getPlayers().get(0));
	                    else if (row == 11)
	                        strokeColor = helpercolor(game.getPlayers().get(1));
	                    else if (row == 0)
	                        strokeColor = helpercolor(game.getPlayers().get(2));
	                    else
	                        strokeColor = helpercolor(game.getPlayers().get(3));

	                    StackPane stack = (StackPane)node;
	                    String hex = String.format("#%02X%02X%02X",
		    	        	    (int)(strokeColor.getRed() * 255),
		    	        	    (int)(strokeColor.getGreen() * 255),
		    	        	    (int)(strokeColor.getBlue() * 255)
		    	        	);

	                    stack.setStyle(
	            	    	    "-fx-background-color: white;" +
	            	    	    "-fx-background-radius: 50%;" + // rounded edges
	            	    	    "-fx-border-color:"+ hex+";" +
	            	    	    "-fx-border-radius: 50%;" +
	            	    	    "-fx-border-width: 3px;" +
	            	    	    "-fx-alignment: center;"
	            	    	);
	                }
	            }

	        }
	        
	        //add firepit
	       ImageView firepit;
	        if(!game.getFirePit().isEmpty()){
	        	Card card= game.getFirePit().get(game.getFirePit().size()-1);
	        	Image firePitImage = new Image(cardImage(card));
	 	        firepit = new ImageView(firePitImage);
	 	        firepit.setFitWidth(130);
	 	        firepit.setFitHeight(100);
	 	        firepit.setPreserveRatio(true);
	 	        center.getChildren().add(firepit);
	 	      
	        }
	        
	        // add firepit 
	      /* if(!game.getFirePit().isEmpty()){
	        	Card card= game.getFirePit().get(game.getFirePit().size()-1);
	        	Image firePitImage = new Image(cardImage(card));
	 	        ImageView firepit = new ImageView(firePitImage);
	 	        firepit.setFitWidth(130);
	 	        firepit.setFitHeight(100);
	 	        firepit.setPreserveRatio(true);

	 	        StackPane firepitStack = new StackPane(firepit);
	 	        firepitStack.setPrefSize(4 , 4 ); // Reserve space
	 	        firepitStack.setAlignment(Pos.CENTER);

	 	        StackPane centerWrapper = new StackPane();
	 	        centerWrapper.setPrefSize(625, 625);
	 	        centerWrapper.setAlignment(Pos.CENTER);
	 	        centerWrapper.getChildren().addAll(gridpane, firepitStack);
	 	        root.setCenter(centerWrapper);
	 	        
	        }*/
	        
	        
	        
	        //add method to add marbles lel track and safezone Done bs not sure fi kaza goz2 
	       
	       for (int i = 0; i < game.getBoard().getTrack().size(); i++) {
	    	    engine.board.Cell Cell = game.getBoard().getTrack().get(i);

	    	    if (Cell.getMarble() != null) {
	    	        Marble Actualmarble = Cell.getMarble(); 
	    	        final Marble thisMarble = Actualmarble; // ✅ Make the reference final for use inside lambda

	    	        Colour colour = thisMarble.getColour();
	    	        int[] postion = trackCoords[i];
	    	        int row = postion[0];
	    	        int column = postion[1];

	    	        ToggleButton marble = new ToggleButton();
	    	        

	    	        marble.setOnAction(e -> {
	    	        	if(game.getCurrentPlayerIndex()==0){
	    	        		
	    	        	try {
    	                    game.selectMarble(thisMarble);
    	                } 
	    	        	
	    	        	catch (InvalidMarbleException f) {
    	                   marble.setSelected(false);
    	                  displayAlert(f.getMessage());
    	                }
	    	        	
	    	        	}
    	            
	    	            if(marble.isSelected()){
	    	            	Color Marblecolor = helpercolorofMarble(thisMarble);
	    	            	 String hex = String.format("#%02X%02X%02X",
	    		    	        	    (int)(Marblecolor.getRed() * 255),
	    		    	        	    (int)(Marblecolor.getGreen() * 255),
	    		    	        	    (int)(Marblecolor.getBlue() * 255)
	    		    	        	);
	    	            	marble.setStyle(
	    	            		    "-fx-background-color: " + hex + ";" +
	    	            		    "-fx-background-radius: 50%;" +
	    	            		    "-fx-border-radius: 50%;" +
	    	            		    "-fx-border-color: brown;" +                // Set stroke to yellow
	    	            		    "-fx-border-width: 5px;" +                   // Optional: set border thickness
	    	            		    "-fx-padding: 0;" +
	    	            		    "-fx-focus-color: transparent;" +
	    	            		    "-fx-faint-focus-color: transparent;"
	    	            		);

	    	            }
	    	           
	    	           else {
	    	        	   Color Marblecolor = helpercolorofMarble(thisMarble);
	    	        	   String hex = String.format("#%02X%02X%02X",
	   	    	        	    (int)(Marblecolor.getRed() * 255),
	   	    	        	    (int)(Marblecolor.getGreen() * 255),
	   	    	        	    (int)(Marblecolor.getBlue() * 255)
	   	    	        	);

	   	    	        	marble.setStyle("-fx-background-color: " + hex + ";" +
	   	    	        	    "-fx-background-radius: 50%;" +
	   	    	        	    "-fx-border-radius: 50%;" +
	   	    	        	    "-fx-border-color: black;" +
	   	    	        	    "-fx-padding: 0;" +
	   	    	        	    "-fx-focus-color: transparent;" +
	   	    	        	    "-fx-faint-focus-color: transparent;");
	    	               // Deselect and remove from selected list
	    	              game.getPlayers().get(game.getCurrentPlayerIndex()).getSelectedMarbles().remove(thisMarble);
	    	           }
	    	        });
	    	        
	    	        Color Marblecolor = helpercolorofMarble(thisMarble);

	    	        // Style the marble as a circle
	    	        Circle circle = new Circle(10,Marblecolor); 
	    	        marble.setShape(circle);
	    	        marble.setMinSize(20, 20);  
	    	        marble.setMaxSize(20, 20);
	    	        marble.setPrefSize(20, 20);
	    	        
	    	        String hex = String.format("#%02X%02X%02X",
	    	        	    (int)(Marblecolor.getRed() * 255),
	    	        	    (int)(Marblecolor.getGreen() * 255),
	    	        	    (int)(Marblecolor.getBlue() * 255)
	    	        	);

	    	        	marble.setStyle("-fx-background-color: " + hex + ";" +
	    	        	    "-fx-background-radius: 50%;" +
	    	        	    "-fx-border-radius: 50%;" +
	    	        	    "-fx-border-color: black;" +
	    	        	    "-fx-padding: 0;" +
	    	        	    "-fx-focus-color: transparent;" +
	    	        	    "-fx-faint-focus-color: transparent;");


	    	        StackPane cell = (StackPane) getNodeFromGridPane(gridpane,row , column);
	    	        cell.getChildren().add(marble);

	    	    }
	    	}

	                         //add safezone marbles
	            for (int i = 0; i < game.getBoard().getSafeZones().size(); i++){
	            	int [][] s= new int[4][2];
	            	if (i==0)
	            		s=safezone1;
	            	else if (i==1)
	            		s=safezone2;
	            	else if (i==2)
	            		s=safezone3;
	            	else 
	            		s=safezone4;
	            	 for (int j = 0; j < game.getBoard().getSafeZones().get(i).getCells().size(); j++){
	            		 if (game.getBoard().getSafeZones().get(i).getCells().get(j).getMarble()!=null){
	            			engine.board.Cell Cell = game.getBoard().getSafeZones().get(i).getCells().get(j);
	            			Marble Actualmarble = Cell.getMarble(); 
	            			final Marble thisMarble = Actualmarble;
	 	                    Colour colour = Actualmarble.getColour();
	 	                    int [] postion =s[j];
	 	                    int row = postion[0];
	 	                    int column = postion[1];
	 	                    ToggleButton marble = new ToggleButton();
	 	                    
	 	                   marble.setOnAction(e -> {
	 	                	  if(game.getCurrentPlayerIndex()==0){
	 		    	        		
	 	 	    	        	try {
	 	     	                    game.selectMarble(thisMarble);
	 	     	                } 
	 	 	    	        	
	 	 	    	        	catch (InvalidMarbleException f) {
	 	     	                   marble.setSelected(false);
	 	     	                  displayAlert(f.getMessage());
	 	     	                }
	 	 	    	        	
	 	 	    	        	}
	 	     	            
	 	 	    	            if(marble.isSelected()){
	 	 	    	            	Color Marblecolor = helpercolorofMarble(thisMarble);
	 	 	    	            	 String hex = String.format("#%02X%02X%02X",
	 	 	    		    	        	    (int)(Marblecolor.getRed() * 255),
	 	 	    		    	        	    (int)(Marblecolor.getGreen() * 255),
	 	 	    		    	        	    (int)(Marblecolor.getBlue() * 255)
	 	 	    		    	        	);
	 	 	    	            	marble.setStyle(
	 	 	    	            		    "-fx-background-color: " + hex + ";" +
	 	 	    	            		    "-fx-background-radius: 50%;" +
	 	 	    	            		    "-fx-border-radius: 50%;" +
	 	 	    	            		    "-fx-border-color: brown;" +                // Set stroke to yellow
	 	 	    	            		    "-fx-border-width: 5px;" +                   // Optional: set border thickness
	 	 	    	            		    "-fx-padding: 0;" +
	 	 	    	            		    "-fx-focus-color: transparent;" +
	 	 	    	            		    "-fx-faint-focus-color: transparent;"
	 	 	    	            		);

	 	 	    	            }
	 	 	    	           
	 	 	    	           else {
	 	 	    	        	   Color Marblecolor = helpercolorofMarble(thisMarble);
	 	 	    	        	   String hex = String.format("#%02X%02X%02X",
	 	 	   	    	        	    (int)(Marblecolor.getRed() * 255),
	 	 	   	    	        	    (int)(Marblecolor.getGreen() * 255),
	 	 	   	    	        	    (int)(Marblecolor.getBlue() * 255)
	 	 	   	    	        	);

	 	 	   	    	        	marble.setStyle("-fx-background-color: " + hex + ";" +
	 	 	   	    	        	    "-fx-background-radius: 50%;" +
	 	 	   	    	        	    "-fx-border-radius: 50%;" +
	 	 	   	    	        	    "-fx-border-color: black;" +
	 	 	   	    	        	    "-fx-padding: 0;" +
	 	 	   	    	        	    "-fx-focus-color: transparent;" +
	 	 	   	    	        	    "-fx-faint-focus-color: transparent;");
	 	 	    	               // Deselect and remove from selected list
	 	 	    	              game.getPlayers().get(game.getCurrentPlayerIndex()).getSelectedMarbles().remove(thisMarble);
	 	 	    	           }
		                    });
	 	                    
	 	                   marble.setUserData(Actualmarble);
	 	            		Circle circle = new Circle(10); 
	 	            		marble.setShape(circle);
	 	            		marble.setMinSize(20, 20);  
	 	            		marble.setMaxSize(20, 20);
	 	            		marble.setPrefSize(20, 20);
	 	            		Color Marblecolor = helpercolorofMarble(Actualmarble);
	 	            		String hex = String.format("#%02X%02X%02X",
	 	            		    (int)(Marblecolor.getRed() * 255),
	 	            		    (int)(Marblecolor.getGreen() * 255),
	 	            		    (int)(Marblecolor.getBlue() * 255)
	 	            		    
	 	            		);
	 	            		
	 	            		marble.setStyle("-fx-background-color: " + hex + ";" +
	 	            			    "-fx-background-radius: 50%;" +
	 	            			    "-fx-border-radius: 50%;" +
	 	            			    "-fx-border-color: black;" +
	 	            			    "-fx-padding: 0;" +
	 	            			    "-fx-focus-color: transparent;" +
	 	            			    "-fx-faint-focus-color: transparent;");
	 	            		
	 	
	 	            		gridpane.add(marble, column, row);
	            			 
	            		 }
	            		 
	            	 }
	            	
	            }
	            
	            
	            


	       
	        
	        // --- Scene Setup ---
	        Scene scene = new Scene(root, 1250, 1000);
	        
	        scene.setOnKeyPressed(event -> {
                if (event.getCode() == KeyCode.F) {
                
                		try {
							game.fieldMarble();
							startGame(humanName);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							displayAlert(e.getMessage());
						}
                		
                		
                }
                	
            });
	        
	        primaryStage.setScene(scene);
	        primaryStage.setTitle("Game Board - Circular Track");
	        primaryStage.show();
	    }

	    
	    
	    //methods

private void displayAlert(String message) {
    Stage alertStage = new Stage();
    alertStage.setTitle("Notice");

    Label label = new Label(message);
    label.setWrapText(true);
    label.setStyle("-fx-font-size: 16px; -fx-text-fill: #333333;");

    Button button = new Button("Continue");
    button.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
    button.setOnAction(event -> alertStage.close());

    VBox vbox = new VBox(20, label, button);
    vbox.setAlignment(Pos.CENTER);
    vbox.setPadding(new Insets(20));
    vbox.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #cccccc; -fx-border-width: 1px;");

    Scene scene = new Scene(vbox, 350, 200);
    alertStage.setScene(scene);
    alertStage.initModality(Modality.APPLICATION_MODAL); // Prevent interaction with the main window
    alertStage.setResizable(false);
    alertStage.showAndWait();
}

	    
	    private static MediaPlayer mediaPlayer;
	    private static boolean isMuted = false;
	    
	    private void initializeAudio() {
	        try {
	            // Use getResource() for proper resource loading
	            String musicFile = getClass().getResource("/background-music-224633.mp3").toString();
	            Media sound = new Media(musicFile);
	            mediaPlayer = new MediaPlayer(sound);
	            
	            // Configure player
	            mediaPlayer.setCycleCount(MediaPlayer.INDEFINITE);
	            mediaPlayer.setVolume(0.7); // 70% volume
	            mediaPlayer.play();
	            
	            // Error listeners
	            mediaPlayer.setOnError(() -> {
	                System.err.println("Audio error: " + mediaPlayer.getError());
	            });
	            
	        } catch (Exception e) {
	            System.err.println("Couldn't load audio: " + e.getMessage());
	            // Continue game without audio
	        }
	    }
	    
	    private void toggleMute() {
	        isMuted = !isMuted;
	        if (mediaPlayer != null) {
	            mediaPlayer.setMute(isMuted);
	        }
	    }
	    
	    private HBox createAudioToggle() {
	        ToggleButton audioToggle = new ToggleButton();
	        audioToggle.setText(isMuted ? "Unmute" : "Mute");
	        
	        Slider volumeSlider = new Slider(0, 1, 0.7);
	        volumeSlider.setPrefWidth(100);
	        volumeSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
	            if (mediaPlayer != null) {
	                mediaPlayer.setVolume(newVal.doubleValue());
	            }
	        });
	        
	        HBox audioBox = new HBox(10, audioToggle, new Label("Volume:"), volumeSlider);
	        audioBox.setAlignment(Pos.CENTER_RIGHT);
	        audioBox.setStyle("-fx-padding: 10; ");
	        
	        audioToggle.setOnAction(e -> {
	            toggleMute();
	            audioToggle.setText(isMuted ? "Unmute" : "Mute");
	        });
	        
	        return audioBox;
	    }
	    
	    
	    
	   /* private Circle createCircle(Color color) {
	        Circle circle = new Circle(10); // radius
	        circle.setFill(color);
	        circle.setStroke(Color.BLACK);
	        return circle;
	    }*/

	    // Place a circle at a given GridPane position
	    private void place(GridPane grid, int row, int col, Color color) {
	    	StackPane stack = new StackPane();
	    	stack.setPrefSize(23, 23);
	    	stack.setStyle("-fx-background-color: white; -fx-border-color: gray;");
	    
	    	stack.setMaxSize(23, 23);
	    	stack.setMinSize(23, 23);

	    	stack.setStyle(
	    	    "-fx-background-color: white;" +
	    	    "-fx-background-radius: 50%;" + // rounded edges
	    	    "-fx-border-color: black;" +
	    	    "-fx-border-radius: 50%;" +
	    	    "-fx-border-width: 2px;" +
	    	    "-fx-alignment: center;"
	    	);
	    	
	        grid.add(stack, col, row);
	    }
	    
	    
	    private VBox createPlayerAreaHorizontal(Player player) {
	        HBox hand = new HBox(4);
	        hand.setAlignment(Pos.CENTER);
	        
	        for (int i = 0; i <player.getHand().size() ; i++) {
	        	ImageView image = new ImageView("/Deck.jpg");
	        	image.setFitHeight(110);
	        	image.setFitWidth(100);
	            hand.getChildren().add(image);
	        }

	        Rectangle colorBox = new Rectangle(10, 10, helpercolor(player));
	        colorBox.setStroke(Color.BLACK);

	        HBox nameBox = new HBox(5, colorBox, new Label("Jana"));
	        nameBox.setAlignment(Pos.CENTER);

	        GridPane homeZone = createHomeZone(player);

	        HBox bottomRow = new HBox(20, hand, homeZone);
	        bottomRow.setAlignment(Pos.CENTER);

	        VBox area = new VBox(5, nameBox, bottomRow);
	        area.setAlignment(Pos.CENTER);
	        return area;
	    }
	    
		   private GridPane createHomeZone(Player player) {
		        GridPane grid = new GridPane();
		        grid.setHgap(5);
		        grid.setVgap(5);
		        
		        int [][] homezone = {{0,0},{0,1},{1,0},{1,1}};
		        for(int i=0; i<player.getMarbles().size(); i++){
		        	int [] pos = homezone[i];
		        	int row = pos[0];
                    int column = pos[1];
		        	ToggleButton marble = new ToggleButton();
		        	marble.setUserData(player.getMarbles().get(i));
            		Circle circle = new Circle(10); // radius 10
            		marble.setShape(circle);
            		marble.setMinSize(20, 20);  // diameter = 2 * radius
            		marble.setMaxSize(20, 20);
            		marble.setPrefSize(20, 20);
            		Color color = helpercolor(player);
            		String hex = String.format("#%02X%02X%02X",
            		    (int)(color.getRed() * 255),
            		    (int)(color.getGreen() * 255),
            		    (int)(color.getBlue() * 255)
            		    
            		);
            		
            		marble.setStyle("-fx-background-color: " + hex + ";" +
            			    "-fx-background-radius: 50%;" +
            			    "-fx-border-radius: 50%;" +
            			    "-fx-border-color: black;" +
            			    "-fx-padding: 0;" +
            			    "-fx-focus-color: transparent;" +
            			    "-fx-faint-focus-color: transparent;");
	                grid.add(marble,row,column);
		        }
		        
		        return grid;
		        
		   }
		        
		  
		   
		   
		   private VBox createPlayerAreaVertical(String playerName, Player player) {
		        VBox hand = new VBox(10);
		        hand.setAlignment(Pos.CENTER);
		        for (int i = 0; i <player.getHand().size() ; i++) {
		        	ImageView image = new ImageView("/Deck.jpg"); 
		        	image.setFitHeight(110);
		        	image.setFitWidth(100);
		            hand.getChildren().add(image);
		        }

		        Rectangle colorBox = new Rectangle(10, 10, helpercolor(player));
		        colorBox.setStroke(Color.BLACK);
		        Label nameLabel = new Label(playerName);

		        GridPane homeZone = createHomeZone(player);

		        VBox area = new VBox(10);
		        area.setAlignment(Pos.CENTER);
		        area.getChildren().addAll(new HBox(5, colorBox, nameLabel), hand, homeZone);
		        return area;
		    }
		   
		   
		 
	    private VBox createPlayerAreaHuman(String playerName, Player player) {
	        HBox hand = new HBox(4);
	        hand.setAlignment(Pos.CENTER);
	        
	         group = new ToggleGroup();
	        
	        for(int i=0; i<player.getHand().size();i++){
	        	ToggleButton card= new ToggleButton();
	        	hand.getChildren().add(card);
	        	card.setPrefHeight(100);
	        	card.setPrefWidth(70);
	        	card.setToggleGroup(group);
	        	
	        	
	        	if(player.getHand().get(i) instanceof Standard){
	        		Standard standard = (Standard) player.getHand().get(i);
	        		card.setUserData(standard);
	        	}
	        	else if (player.getHand().get(i) instanceof Burner)
	        		card.setUserData(player.getHand().get(i));
	        	else
	        		card.setUserData(player.getHand().get(i));
	        	
	        	//add photo to button
	        	Image image= new Image(cardImage(player.getHand().get(i)));
	        	ImageView view = new ImageView(image);
	        	view.setFitHeight(130);
	        	view.setFitWidth(100);
	        	card.setGraphic(view);
	        	
	        	//ANA HENA add action l button
	        }
	            

	        Rectangle colorBox = new Rectangle(10, 10, helpercolor(player));
	        colorBox.setStroke(Color.BLACK);

	        HBox nameBox = new HBox(5, colorBox, new Label(playerName));
	        nameBox.setAlignment(Pos.CENTER);

	        GridPane homeZone = createHomeZone(player);
	        
	        Button play = new Button("play");
	        play.setPrefHeight(70);
	        play.setPrefWidth(70);
	        
	       

	        HBox bottomRow = new HBox(20, hand, homeZone,play);
	        bottomRow.setAlignment(Pos.CENTER);

	        VBox area = new VBox(5, nameBox, bottomRow);
	        area.setAlignment(Pos.CENTER);
	        
	        play.setOnAction(event -> {
	        	Card selectedcard;
	            // Your code here
	        	if(group.getSelectedToggle()!=null){
	        		selectedcard = (Card) group.getSelectedToggle().getUserData();
	        		try{
		            	game.selectCard(selectedcard);
		            }
		            catch(InvalidCardException ex){
		            	displayAlert(ex.getMessage());
		            }
	        	}
	            
	            el3ab(0); 
	        });
	        
	   
	        
	        return area;
	    }
	    
	    
	    
	    public String cardImage(Card card) {
	        if (card instanceof Standard) {
	            if (((Standard) card).getRank() == 1 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/ace_of_clubs.png";
	            if (((Standard) card).getRank() == 1 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/ace_of_diamonds.png";
	            if (((Standard) card).getRank() == 1 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/ace_of_hearts.png";
	            if (((Standard) card).getRank() == 1 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/ace_of_spades.png";
	            if (((Standard) card).getRank() == 2 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/2_of_clubs.png";
	            if (((Standard) card).getRank() == 2 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/2_of_diamonds.png";
	            if (((Standard) card).getRank() == 2 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/2_of_hearts.png";
	            if (((Standard) card).getRank() == 2 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/2_of_spades.png";
	            if (((Standard) card).getRank() == 3 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/3_of_clubs.png";
	            if (((Standard) card).getRank() == 3 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/3_of_diamonds.png";
	            if (((Standard) card).getRank() == 3 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/3_of_hearts.png";
	            if (((Standard) card).getRank() == 3 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/3_of_spades.png";
	            if (((Standard) card).getRank() == 4 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/4_of_clubs.png";
	            if (((Standard) card).getRank() == 4 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/4_of_diamonds.png";
	            if (((Standard) card).getRank() == 4 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/4_of_hearts.png";
	            if (((Standard) card).getRank() == 4 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/4_of_spades.png";
	            if (((Standard) card).getRank() == 5 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/5_of_clubs.png";
	            if (((Standard) card).getRank() == 5 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/5_of_diamonds.png";
	            if (((Standard) card).getRank() == 5 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/5_of_hearts.png";
	            if (((Standard) card).getRank() == 5 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/5_of_spades.png";
	            if (((Standard) card).getRank() == 6 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/6_of_clubs.png";
	            if (((Standard) card).getRank() == 6 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/6_of_diamonds.png";
	            if (((Standard) card).getRank() == 6 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/6_of_hearts.png";
	            if (((Standard) card).getRank() == 6 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/6_of_spades.png";
	            if (((Standard) card).getRank() == 7 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/7_of_clubs.png";
	            if (((Standard) card).getRank() == 7 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/7_of_diamonds.png";
	            if (((Standard) card).getRank() == 7 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/7_of_hearts.png";
	            if (((Standard) card).getRank() == 7 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/7_of_spades.png";
	            if (((Standard) card).getRank() == 8 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/8_of_clubs.png";
	            if (((Standard) card).getRank() == 8 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/8_of_diamonds.png";
	            if (((Standard) card).getRank() == 8 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/8_of_hearts.png";
	            if (((Standard) card).getRank() == 8 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/8_of_spades.png";
	            if (((Standard) card).getRank() == 9 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/9_of_clubs.png";
	            if (((Standard) card).getRank() == 9 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/9_of_diamonds.png";
	            if (((Standard) card).getRank() == 9 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/9_of_hearts.png";
	            if (((Standard) card).getRank() == 9 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/9_of_spades.png";
	            if (((Standard) card).getRank() == 10 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/10_of_clubs.png";
	            if (((Standard) card).getRank() == 10 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/10_of_diamonds.png";
	            if (((Standard) card).getRank() == 10 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/10_of_hearts.png";
	            if (((Standard) card).getRank() == 10 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/10_of_spades.png";
	            if (((Standard) card).getRank() == 11 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/jack_of_clubs2.png";
	            if (((Standard) card).getRank() == 11 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/jack_of_diamonds2.png";
	            if (((Standard) card).getRank() == 11 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/jack_of_hearts2.png";
	            if (((Standard) card).getRank() == 11 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/jack_of_spades2.png";
	            if (((Standard) card).getRank() == 12 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/queen_of_clubs2.png";
	            if (((Standard) card).getRank() == 12 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/queen_of_diamonds2.png";
	            if (((Standard) card).getRank() == 12 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/queen_of_hearts2.png";
	            if (((Standard) card).getRank() == 12 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/queen_of_spades2.png";
	            if (((Standard) card).getRank() == 13 && ((Standard) card).getSuit() == Suit.CLUB)
	                return "/king_of_clubs2.png";
	            if (((Standard) card).getRank() == 13 && ((Standard) card).getSuit() == Suit.DIAMOND)
	                return "/king_of_diamonds2.png";
	            if (((Standard) card).getRank() == 13 && ((Standard) card).getSuit() == Suit.HEART)
	                return "/king_of_hearts2.png";
	            if (((Standard) card).getRank() == 13 && ((Standard) card).getSuit() == Suit.SPADE)
	                return "/king_of_spades2.png";
	        }
	        else if (card instanceof Burner) 
	            return "/Burner.jpeg";
	        
	         else 
	            return "/Saver.jpeg";
	        

	        return null;
	    }
	    
	    
	    PauseTransition pause = new PauseTransition(Duration.seconds(4)); // make it shorter for testing

	    private void el3ab(int count){
	        if (count >= 4)
	            return;

	        if (count == 0) { // human player
	            if (game.canPlayTurn()) {
	                if (game.getPlayers().get(0).getSelectedCard() != null &&
	                    game.getPlayers().get(0).getSelectedCard() instanceof Seven &&
	                    game.getPlayers().get(0).getSelectedMarbles().size() == 2) {
	                    splitscene();
	                }

	                try {
	                    game.playPlayerTurn();
	                    
	                    game.endPlayerTurn();
	                    startGame(game.getPlayers().get(0).getName());

	                    if (game.checkWin() != null)
	                        showEndGameScreen(game.checkWin());
	                    else {
	                        pause.setOnFinished(e -> el3ab(count + 1));
	                        pause.play();
	                    }
	                    return;
	                } catch (GameException ex) {
	                    displayAlert(ex.getMessage());
	                    
	                    game.endPlayerTurn();
		                startGame(game.getPlayers().get(0).getName());
		                pause.setOnFinished(e -> el3ab(count + 1));
		                pause.play();
	                }

	            } else {
	                game.endPlayerTurn();
	                startGame(game.getPlayers().get(0).getName());
	                pause.setOnFinished(e -> el3ab(count + 1));
	                pause.play();
	            }

	        } else { // CPU players
	            CPU cpu = (CPU) game.getPlayers().get(game.getCurrentPlayerIndex());
	            
	            if(game.canPlayTurn()){
	            
	            try {
	                cpu.play();
	                game.endPlayerTurn();
	                startGame(game.getPlayers().get(0).getName());

	                if (game.checkWin() != null) {
	                    showEndGameScreen(game.checkWin());
	                } else {
	                    pause.setOnFinished(e -> el3ab(count + 1));
	                    pause.play();
	                }

	            } catch (GameException ex) {
	                // Handle exception or continue
	            }
	            
	            }
	            
	            else{
	            	game.endPlayerTurn();
	                startGame(game.getPlayers().get(0).getName());
	                pause.setOnFinished(e -> el3ab(count + 1));
	                pause.play();
	            }
	            
	        }
	    }

	    
	    private void splitscene(){
	    	 Stage splitStage = new Stage();
	    	    splitStage.setTitle("Edit Split Distance");

	    	    Label label = new Label("Edit Split Distance");
	    	    label.setWrapText(true);
	    	    label.setStyle("-fx-font-size: 16px; -fx-text-fill: #333333;");
	    	    
	    	    TextArea split = new TextArea();
	    	    
	    	    //edit size 

	    	    Button button = new Button("Continue");
	    	    button.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
	    	    button.setOnAction(event -> {
		            // Your code here
		            int s = Integer.parseInt(split.getText());
		            try{
		            	game.editSplitDistance(s);
		            }
		            catch(SplitOutOfRangeException ex){
		            	displayAlert("split distance must be between 1 and 6"); 	
		            }
		            splitStage.close();
		        });
	    	    
	    	    
	    	    
	    	    VBox vbox = new VBox(20, label, split, button);
	    	    vbox.setAlignment(Pos.CENTER);
	    	    vbox.setPadding(new Insets(20));
	    	    vbox.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #cccccc; -fx-border-width: 1px;");

	    	    Scene scene = new Scene(vbox, 350, 200);
	    	    splitStage.setScene(scene);
	    	    splitStage.initModality(Modality.APPLICATION_MODAL); // Prevent interaction with the main window
	    	    splitStage.setResizable(false);
	    	    splitStage.showAndWait();
	    	    
	    	
	    }
	    
	  /*  public boolean checkplay(){
	    	
	    	boolean canplay= true;
	    	
	    	 // Retrieve a list of actionable marbles from the board manager.
	        ArrayList<Marble> actionableMarbles = game.getBoard().getActionableMarbles();
	        ArrayList<Card> hand= game.getPlayers().get(0).getHand();
	        
	     // Iterate through each card in the hand.
	        for (Card card : hand ) {
	            // Select the card to be played.
	        	try{
	        		game.selectCard(card);
	        	}
	        	catch(InvalidCardException ex){
	        		
	        	}
	            
	            // Prepare a list to keep track of valid marble counts for the action.
	            ArrayList<Integer> counts = new ArrayList<>();
	            for(int i = 0; i < 3; i++) { // Check for 0 or 1 or 2 marbles to act upon.
	                if(actionableMarbles.size() >= i) {
	                    ArrayList<Marble> testMarbles = new ArrayList<>();
	                    for(int j = 0; j < i; j++) {
	                        testMarbles.add(actionableMarbles.get(j));
	                    }
	                    
	                    // Validate the size of the marble group against the card's rules.
	                    if(card.validateMarbleSize(testMarbles)) {
	                        counts.add(i);
	                    }
	                }
	            }
	            
	            for(int i = 0; i < counts.size(); i++) {   
	                if(counts.get(i) == 0) {
	                    try {
	                        // Attempt to act with no marbles if the count is 0.
	                        game.getPlayers().get(0).getSelectedCard().act(new ArrayList<>());
	                        return true;
	                         
	                    }
	                    catch(Exception e) {
	                        // Ignore exceptions and continue trying other possibilities.
	                    	canplay = false;
	                    }
	                    
	                 
	                }
	                
	                else if(counts.get(i) == 1) {
	                    // Attempt to act with one marble.
	                    ArrayList<Marble> toSend = new ArrayList<>();
	                    
	                    for(Marble marble : actionableMarbles) {
	                        toSend.add(marble);
	                        if(card.validateMarbleColours(toSend)) {
	                            try {
	                            	game.getPlayers().get(0).getSelectedCard().act(toSend);
	                            	 return true; 
	                                
	                            }
	                            catch(Exception e) {
	                                // Ignore exceptions and continue.
	                            	canplay = false;
	                            }
	                          
	                        }
	                        toSend.clear();
	                    }
	                }
	                else {
	                    // Attempt to act with two marbles.
	                    ArrayList<Marble> toSend = new ArrayList<>();
	                    for(int j = 0; j < actionableMarbles.size(); j++) {
	                        for(int k = j+1; k < actionableMarbles.size(); k++) {
	                            toSend.add(actionableMarbles.get(j));
	                            toSend.add(actionableMarbles.get(k));
	                            if(card.validateMarbleColours(toSend)) {
	                                try {
	                                	game.getPlayers().get(0).getSelectedCard().act(toSend);
	                                    return true ; // Return after successful action.
	                                }
	                                catch(Exception e) {
	                                	canplay = false;
	                                    // Ignore exceptions and continue.
	                                }
	                            }
	                            toSend.clear();
	                        }
	                    }
	                }
	            }
	        }
	        
	        return canplay;
	    }*/
	    
	    private void showEndGameScreen(Colour winningColour) {
	        if (winningColour == null) return;

	        StackPane root = new StackPane();

	        // 1. Background Image with proper scaling
	        Image backgroundImage = new Image("/winner.jpeg");
	        ImageView backgroundView = new ImageView(backgroundImage);
	        backgroundView.setPreserveRatio(true);
	        backgroundView.setFitWidth(1250);
	        backgroundView.setFitHeight(970);

	        // 2. Lighter overlay
	        VBox endLayout = new VBox(20);
	        endLayout.setAlignment(Pos.CENTER);
	        endLayout.setPadding(new Insets(40));
	        endLayout.setStyle("-fx-background-color: rgba(0,0,0,0.4); -fx-background-radius: 20;"); // Reduced opacity
	        endLayout.setEffect(new DropShadow(15, Color.GOLD)); // Warmer shadow

	        // 3. Enhanced text visibility
	        Label winnerLabel = new Label("VICTORY ACHIEVED!");
	        winnerLabel.setStyle("-fx-font-size: 48px; -fx-font-weight: bold; -fx-text-fill: #ffffff; -fx-effect: dropshadow(gaussian, #000000, 10, 0.5, 0, 0);");

	        // 4. Safer winner identification
	        String winnerName = "MYSTERIOUS STRANGER";
	        if (game != null && game.getPlayers() != null) {
	            for (Player player : game.getPlayers()) {
	                if (player != null && player.getColour() == winningColour) {
	                    winnerName = (player == game.getPlayers().get(0)) ? 
	                        player.getName() : 
	                        (player.getColour() == Colour.RED) ? CPU1name :
	                        (player.getColour() == Colour.BLUE) ? CPU2name : CPU3name;
	                    break;
	                }
	            }
	        }

	        // 5. Improved winner name styling
	        Label winnerText = new Label(winnerName + " WINS!");
	        winnerText.setStyle("-fx-font-size: 36px; -fx-font-weight: bold; -fx-text-fill: " + 
	            helpercolor(game.getPlayers().stream()
	                .filter(p -> p.getColour() == winningColour)
	                .findFirst()
	                .orElse(null))
	                .toString().replace("0x", "#") + "; -fx-effect: dropshadow(gaussian, #000000, 10, 0.5, 0, 0);");

	        // 6. More prominent button
	        Button menuButton = new Button("RETURN TO MAIN MENU");
	        menuButton.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; "
	            + "-fx-background-color: #3498db; -fx-text-fill: white; -fx-padding: 15 40; "
	            + "-fx-background-radius: 8;");
	        
	        // Hover effect
	        menuButton.setOnMouseEntered(e -> menuButton.setStyle("-fx-background-color: #2980b9; " + menuButton.getStyle()));
	        menuButton.setOnMouseExited(e -> menuButton.setStyle("-fx-background-color: #3498db; " + menuButton.getStyle()));

	        // Assembly
	        endLayout.getChildren().addAll(winnerLabel, winnerText, menuButton);
	        root.getChildren().addAll(backgroundView, endLayout);

	        Scene endScene = new Scene(root, 1250, 970);
	        primaryStage.setScene(endScene);
	        menuButton.setOnAction(e -> showStartScreen());
	    }
	    
	    public Node getNodeFromGridPane(GridPane gridPane, int row, int column) {
	        for (Node node : gridPane.getChildren()) {
	            Integer rowIndex = GridPane.getRowIndex(node);
	            Integer colIndex = GridPane.getColumnIndex(node);

	            // Default values if not explicitly set
	            int actualRow = rowIndex == null ? 0 : rowIndex;
	            int actualCol = colIndex == null ? 0 : colIndex;

	            if (actualRow == row && actualCol == column) {
	                return node;
	            }
	        }
	        return null; // Not found
	    }
	    
	    public static void trapAlert(Colour c) {
	        Stage alertrape = new Stage();
	        alertrape.setTitle("Notice");

	        Label labelt = new Label("trap cell indicated");
	        labelt.setWrapText(true);
	        labelt.setStyle("-fx-font-size: 16px; -fx-text-fill: #333333;");

	        Button button = new Button("Continue");
	        button.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-font-weight: bold;");
	        button.setOnAction(event -> alertrape.close());

	        VBox vbox = new VBox(20, labelt, button);
	        vbox.setAlignment(Pos.CENTER);
	        vbox.setPadding(new Insets(20));
	        vbox.setStyle("-fx-background-color: #f0f0f0; -fx-border-color: #cccccc; -fx-border-width: 1px;");

	        Scene scene = new Scene(vbox, 350, 200);
	        alertrape.setScene(scene);
	        alertrape.initModality(Modality.APPLICATION_MODAL); // Prevent interaction with the main window
	        alertrape.setResizable(false);
	        alertrape.showAndWait();
	    }

	    	
	    
	
	    

	    public static void main(String[] args) {
	        launch(args);
	    }
} 