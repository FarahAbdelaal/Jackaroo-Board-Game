package ms3;

import model.card.Card;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

public class controller {

    private String[] playerNames;
    private Card[] currentPlayerCards;
    private int currentPlayerIndex;

    // Initialize the game
    public void startGame() {
       // gameBoard.updatePlayerTurn();
        //gameBoard.updateGameUI();
    }

    // Handle card selection
    public void handleCardSelection(ActionEvent event) {
        // Logic to handle card selection
        String selectedCard = ((Card) event.getSource()).toString();
        System.out.println("Card selected: " + selectedCard);
    }

    // Handle marble selection (clicking on the board)
    public void handleMarbleSelection(int row, int col) {
        // Update marble's position or selection
        System.out.println("Marble selected at: (" + row + ", " + col + ")");
        // Implement more detailed logic for marble movement
    }

    // Update the turn and switch between players
    public void updateTurn() {
        currentPlayerIndex = (currentPlayerIndex + 1) % 4; // Rotate players
      //  gameBoard.updatePlayerTurn(); // Update UI with the new current player
      //  gameBoard.updateGameUI(); // Refresh UI after each turn
    }

    // Example method for CPU actions (automatic)
    public void cpuTurn() {
        // Simulate CPU actions (e.g., select a card and move marbles)
        int cpuMove = (int) (Math.random() * 4);
        System.out.println("CPU Player " + playerNames[currentPlayerIndex] + " makes a move: " + cpuMove);
    }
   
}

