package model;

public enum Colour {
    GREEN, RED, YELLOW, BLUE
}
